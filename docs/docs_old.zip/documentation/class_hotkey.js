var class_hotkey =
[
    [ "ClearCharges", "class_hotkey.html#a7d290d1777e2971d3bbf99d23322d4af", null ],
    [ "Disable", "class_hotkey.html#a0b90f1841f8cbe70bf62447affd70bd1", null ],
    [ "Enable", "class_hotkey.html#ae078d4716dbd3a3c703a3ef341e56562", null ],
    [ "HideMoreInfo", "class_hotkey.html#a9362ee088eb695642f30c3b8818d0b1a", null ],
    [ "OnPointerClick", "class_hotkey.html#a86ced9a614ad8d537fcab4738abcb0ef", null ],
    [ "PreviewCast", "class_hotkey.html#a209f6726592cf69b7e21bd68ced48cb3", null ],
    [ "ShowMoreInfo", "class_hotkey.html#ae8ab38a3ddf49344ede61f8fb67892c5", null ],
    [ "UpdateCost", "class_hotkey.html#a15822d970e7f05f8ea8ef4069a4e245a", null ],
    [ "UpdateName", "class_hotkey.html#a414aefec4d51bfa4b6fc68fcb8dce841", null ],
    [ "enabled", "class_hotkey.html#a91d3325ffb1aa3fd83dbe59f6630b796", null ],
    [ "hidden", "class_hotkey.html#aff210fac7bfb6cfdf469b02d6cd7e71a", null ],
    [ "preset", "class_hotkey.html#a98f88450edff67278329260ff2e5ce2b", null ],
    [ "showCastRange", "class_hotkey.html#a960d18fbb18716a6cb3db53b46981cd1", null ],
    [ "spell", "class_hotkey.html#acdccc2b352e81fbc8075f5ddb77cd6df", null ]
];