var class_transfer_u_i =
[
    [ "TransactionType", "class_transfer_u_i.html#acb894008318cb07b7144beb2d6d81606", [
      [ "Buy", "class_transfer_u_i.html#acb894008318cb07b7144beb2d6d81606a831a28f1e8df07c553fcd59546465d13", null ],
      [ "Give", "class_transfer_u_i.html#acb894008318cb07b7144beb2d6d81606a2f355d9fa7accc561d3edc335de2fbcf", null ],
      [ "Sell", "class_transfer_u_i.html#acb894008318cb07b7144beb2d6d81606a3068c5a98c003498f1fec0c489212e8b", null ],
      [ "Take", "class_transfer_u_i.html#acb894008318cb07b7144beb2d6d81606aa1df5b634fdadddf5a2170304c556b90", null ]
    ] ],
    [ "HideUI", "class_transfer_u_i.html#a5c4b5956098b374e40ea084d7fbe7739", null ],
    [ "Preview", "class_transfer_u_i.html#a9d2e7c3708193e3d51fe8539f9c41a75", null ],
    [ "Preview", "class_transfer_u_i.html#a52bd586cae27d6570e207d856457a116", null ],
    [ "ShowUI", "class_transfer_u_i.html#acb1dacb30d206743a569f8dc6bf9e5e4", null ],
    [ "transactionType", "class_transfer_u_i.html#a7a235277eb0406680963562b2088d136", null ]
];