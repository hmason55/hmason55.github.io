var class_data_slot =
[
    [ "AssignPlayerData", "class_data_slot.html#a104284ff9c03da56e871e2f39d345e0b", null ],
    [ "DeletePlayerData", "class_data_slot.html#aae68b8b9d2f07c2d634e82493d29c05d", null ],
    [ "LoadGame", "class_data_slot.html#a8c5e92e015138b1ec785465db9ff65a6", null ],
    [ "UnsetPlayerData", "class_data_slot.html#a2d8c55c9436701f7d2a12ab7388dcdec", null ],
    [ "portrait", "class_data_slot.html#abe2454953aa5b018407db6ebbdc18083", null ]
];