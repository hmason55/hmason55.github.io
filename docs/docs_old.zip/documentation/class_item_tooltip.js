var class_item_tooltip =
[
    [ "Reset", "class_item_tooltip.html#a4db0f30912c9b31ac912dbac40b17185", null ],
    [ "Snap", "class_item_tooltip.html#ae6eb8ab5acd326e431e46a3df5b76fa4", null ],
    [ "UpdateTooltip", "class_item_tooltip.html#a51e15cd0c208c14105cc8bedf452385b", null ]
];