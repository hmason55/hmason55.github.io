var class_turn =
[
    [ "Turn", "class_turn.html#a6446f2b617305c390dce97e1c7242066", null ],
    [ "baseUnit", "class_turn.html#a59d549b1393677617e4237dcab3e27f9", null ],
    [ "priority", "class_turn.html#aad40e669aa7299a23aa01c1756edd975", null ]
];