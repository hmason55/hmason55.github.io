var class_character =
[
    [ "BeardType", "class_character.html#afc1fe7f790870a92fe62d3e57296de81", [
      [ "None", "class_character.html#afc1fe7f790870a92fe62d3e57296de81a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Beard_0", "class_character.html#afc1fe7f790870a92fe62d3e57296de81ab8cdcd9acdceac22252517aa9a816a01", null ],
      [ "Beard_1", "class_character.html#afc1fe7f790870a92fe62d3e57296de81a0851930551823ac3b21b499fd8763bd4", null ],
      [ "Beard_2", "class_character.html#afc1fe7f790870a92fe62d3e57296de81a838e63548f79761de7869ccf7439e701", null ],
      [ "Beard_3", "class_character.html#afc1fe7f790870a92fe62d3e57296de81aa1f19a4b0cacd92395091d6658cb4036", null ],
      [ "Beard_4", "class_character.html#afc1fe7f790870a92fe62d3e57296de81ae6316a13bb05c3098700716688d36d94", null ],
      [ "Beard_5", "class_character.html#afc1fe7f790870a92fe62d3e57296de81a46ea58ac8e495ad07a75ddceccb458a8", null ],
      [ "Beard_6", "class_character.html#afc1fe7f790870a92fe62d3e57296de81aef2d4395372775f26d9d803311996884", null ],
      [ "Beard_7", "class_character.html#afc1fe7f790870a92fe62d3e57296de81a116cf87a1571ff2f43bd5fdbecf60e11", null ],
      [ "Beard_8", "class_character.html#afc1fe7f790870a92fe62d3e57296de81a1cc77dfa5d8fca74576ba6e75445dd07", null ]
    ] ],
    [ "EyebrowType", "class_character.html#a7ba51a2ab6ee02a615df9275665c5e4c", [
      [ "None", "class_character.html#a7ba51a2ab6ee02a615df9275665c5e4ca6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Eyebrow_0", "class_character.html#a7ba51a2ab6ee02a615df9275665c5e4cae370c2059dcc8f848bcbc9f6449ab718", null ],
      [ "Eyebrow_1", "class_character.html#a7ba51a2ab6ee02a615df9275665c5e4ca44ba5502eddb30831b1c23836f93dca9", null ],
      [ "Eyebrow_2", "class_character.html#a7ba51a2ab6ee02a615df9275665c5e4cabb5f8d5e7aa99f129a22eb9cfe502094", null ]
    ] ],
    [ "FaceType", "class_character.html#aae9a74ea017a528536789f545094d628", [
      [ "Elf_0", "class_character.html#aae9a74ea017a528536789f545094d628ae94f97fa35651694344bb6ba7f380572", null ],
      [ "Elf_1", "class_character.html#aae9a74ea017a528536789f545094d628ad97fc95d523bf6dfaa932dbe99597324", null ],
      [ "Elf_2", "class_character.html#aae9a74ea017a528536789f545094d628a693718e65755b68c6478ae703d16b1ae", null ],
      [ "Human_0", "class_character.html#aae9a74ea017a528536789f545094d628aeca678a9905614fff5d0ba295239a0a6", null ],
      [ "Human_1", "class_character.html#aae9a74ea017a528536789f545094d628a208cc51c094faa7aeda24d741ab48336", null ],
      [ "Human_2", "class_character.html#aae9a74ea017a528536789f545094d628a29ccde01b85148882e25d57d155e4c8b", null ],
      [ "Orc_0", "class_character.html#aae9a74ea017a528536789f545094d628a1aa145c18e732e682374a3ba3076d5b3", null ],
      [ "Orc_1", "class_character.html#aae9a74ea017a528536789f545094d628ad14e10b7ed06f3157e1b496d7380fe3b", null ]
    ] ],
    [ "HairColor", "class_character.html#a7940fffce9bfadb9e7abf15490cf8bb0", [
      [ "Platinum", "class_character.html#a7940fffce9bfadb9e7abf15490cf8bb0abf381e2261c6d3b5b91866d8c966df3d", null ],
      [ "Blonde", "class_character.html#a7940fffce9bfadb9e7abf15490cf8bb0a2a6ef591687a14d276872bedab511ead", null ],
      [ "Amber", "class_character.html#a7940fffce9bfadb9e7abf15490cf8bb0a88068e33c78eb72f1b371c7110846085", null ],
      [ "Chestnut", "class_character.html#a7940fffce9bfadb9e7abf15490cf8bb0a98f2d2794c75ac86f8c89296dcbd5592", null ],
      [ "Chocolate", "class_character.html#a7940fffce9bfadb9e7abf15490cf8bb0a6ea408ea56e8b710aa240004af7580c1", null ],
      [ "Auburn", "class_character.html#a7940fffce9bfadb9e7abf15490cf8bb0a6877cb2dd003a6b27e352890bfc393e1", null ],
      [ "Red", "class_character.html#a7940fffce9bfadb9e7abf15490cf8bb0aee38e4d5dd68c4e440825018d549cb47", null ],
      [ "Gray", "class_character.html#a7940fffce9bfadb9e7abf15490cf8bb0a994ae1d9731cebe455aff211bcb25b93", null ],
      [ "White", "class_character.html#a7940fffce9bfadb9e7abf15490cf8bb0a25a81701fbfa4a1efdf660a950c1d006", null ]
    ] ],
    [ "HairType", "class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733", [
      [ "None", "class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Long_0", "class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733a2b280aa8bb62b09f18c1b91612e8cb37", null ],
      [ "Long_1", "class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733ad2e09ac24d1895e1c24a26d641ddc21d", null ],
      [ "Long_2", "class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733a850a0beb0f7a1e72aa93306fe0676291", null ],
      [ "Long_3", "class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733afca987f95144f23e45367faa3e76afb3", null ],
      [ "Medium_0", "class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733a85298f5d724590d2823708c9b2044def", null ],
      [ "Medium_1", "class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733a8725fa5091779224e174522862ddb056", null ],
      [ "Medium_2", "class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733af53c67f292f7fa2403f6eac23cc4ce18", null ],
      [ "Medium_3", "class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733ab94b802016c75344228e200b3dd06007", null ],
      [ "Short_0", "class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733a1c660d6b6abb181b42b3a8d1f60a0ab3", null ],
      [ "Short_1", "class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733a436ae8b8d8d26122074321e98e9f2208", null ],
      [ "Short_2", "class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733a5ba0fc1a8d7fde835c0cd42fb4d86cfe", null ]
    ] ],
    [ "MouthType", "class_character.html#aaefb65409260b3ad1511951aab1ddd6c", [
      [ "Elf_0", "class_character.html#aaefb65409260b3ad1511951aab1ddd6cae94f97fa35651694344bb6ba7f380572", null ],
      [ "Elf_1", "class_character.html#aaefb65409260b3ad1511951aab1ddd6cad97fc95d523bf6dfaa932dbe99597324", null ],
      [ "Human_0", "class_character.html#aaefb65409260b3ad1511951aab1ddd6caeca678a9905614fff5d0ba295239a0a6", null ],
      [ "Human_1", "class_character.html#aaefb65409260b3ad1511951aab1ddd6ca208cc51c094faa7aeda24d741ab48336", null ],
      [ "Human_2", "class_character.html#aaefb65409260b3ad1511951aab1ddd6ca29ccde01b85148882e25d57d155e4c8b", null ],
      [ "Human_3", "class_character.html#aaefb65409260b3ad1511951aab1ddd6ca9f1ffde7012e729f41429a0b711823ab", null ],
      [ "Orc_0", "class_character.html#aaefb65409260b3ad1511951aab1ddd6ca1aa145c18e732e682374a3ba3076d5b3", null ],
      [ "Orc_1", "class_character.html#aaefb65409260b3ad1511951aab1ddd6cad14e10b7ed06f3157e1b496d7380fe3b", null ]
    ] ],
    [ "NoseType", "class_character.html#a638a71f8525dc3a59596f7f4a7836036", [
      [ "Elf_0", "class_character.html#a638a71f8525dc3a59596f7f4a7836036ae94f97fa35651694344bb6ba7f380572", null ],
      [ "Elf_1", "class_character.html#a638a71f8525dc3a59596f7f4a7836036ad97fc95d523bf6dfaa932dbe99597324", null ],
      [ "Human_0", "class_character.html#a638a71f8525dc3a59596f7f4a7836036aeca678a9905614fff5d0ba295239a0a6", null ],
      [ "Human_1", "class_character.html#a638a71f8525dc3a59596f7f4a7836036a208cc51c094faa7aeda24d741ab48336", null ],
      [ "Human_2", "class_character.html#a638a71f8525dc3a59596f7f4a7836036a29ccde01b85148882e25d57d155e4c8b", null ],
      [ "Human_3", "class_character.html#a638a71f8525dc3a59596f7f4a7836036a9f1ffde7012e729f41429a0b711823ab", null ],
      [ "Orc_0", "class_character.html#a638a71f8525dc3a59596f7f4a7836036a1aa145c18e732e682374a3ba3076d5b3", null ],
      [ "Orc_1", "class_character.html#a638a71f8525dc3a59596f7f4a7836036ad14e10b7ed06f3157e1b496d7380fe3b", null ]
    ] ],
    [ "SkinColor", "class_character.html#a726214a0fe480fffada7772697764824", [
      [ "Elf_Dark", "class_character.html#a726214a0fe480fffada7772697764824a47543040fc89d7dac80d595f061145c1", null ],
      [ "Human_Dark", "class_character.html#a726214a0fe480fffada7772697764824a3cedf322d3207950a243f8a1c11199a0", null ],
      [ "Human_Light", "class_character.html#a726214a0fe480fffada7772697764824a05301bbb3c2c081102cfdfd77f7ad977", null ],
      [ "Human_Medium", "class_character.html#a726214a0fe480fffada7772697764824ae28a084b2066d99928aded041ef09f56", null ],
      [ "Orc_Medium", "class_character.html#a726214a0fe480fffada7772697764824ac7756d61bbbcdbe68fd9b8ee7faaa8d3", null ]
    ] ],
    [ "Character", "class_character.html#aeb15ed2a88e93ac33887094427a52476", null ],
    [ "name", "class_character.html#adbfa3b858f99f337203a1bec67b2fe45", null ],
    [ "beardType", "class_character.html#a77735a4eeb0530c85de8e53145cb6044", null ],
    [ "eyebrowType", "class_character.html#a470cb22e12212f2cb43f77b1c06445d3", null ],
    [ "faceType", "class_character.html#ab7552f9cfc719cb2b86820ac9381764b", null ],
    [ "hairColor", "class_character.html#a5814d461d5a35e4784864f4287d0d458", null ],
    [ "hairType", "class_character.html#add6905ded7f0e4c0573038bd488b3cea", null ],
    [ "mouthType", "class_character.html#a4199c2476940533add49ababfc7cba52", null ],
    [ "noseType", "class_character.html#a451957556cb1b0aaa89b9dcf36b2b1dd", null ],
    [ "skinColor", "class_character.html#af3528fb3651c738431375d8c39b4651c", null ]
];