var class_hitpoint_u_i =
[
    [ "UpdateHitpoints", "class_hitpoint_u_i.html#a276f8fb6a38204f4155f32c48c6322af", null ],
    [ "baseUnit", "class_hitpoint_u_i.html#a6dfd0f75896f8f70dc7f2dc0ff34fb42", null ]
];