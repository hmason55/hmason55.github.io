var class_path_node =
[
    [ "PathNode", "class_path_node.html#a30a770f5dcef4859cced1063f003c85c", null ],
    [ "distanceFromStart", "class_path_node.html#a4aefccdcbd1561396d0b7d93f3738c38", null ],
    [ "parentNode", "class_path_node.html#abb55342c621b16a3eab5cc4d254fe419", null ],
    [ "position", "class_path_node.html#adb09edeff29736df426b6c665f773906", null ],
    [ "totalDistance", "class_path_node.html#abb1849c6d76a35af78dd4fa84e1b7d3c", null ],
    [ "trueDistanceFromEnd", "class_path_node.html#a94623e99b6e76db825843d7fbfd57ef9", null ],
    [ "walkable", "class_path_node.html#a954f777fd998af56c4acc5f78cbf41ca", null ]
];