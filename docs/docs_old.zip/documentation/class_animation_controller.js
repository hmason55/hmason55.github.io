var class_animation_controller =
[
    [ "animationFrame", "class_animation_controller.html#a97a1baad1d6f5f5e48145cad30ec8d16", null ],
    [ "animationSpeed", "class_animation_controller.html#a9a5d475137de1a9cb890396d404104a4", null ]
];