var class_swipe_controller =
[
    [ "OnBeginDrag", "class_swipe_controller.html#a6f7b3f648901c5cc45a9da620ec7ccfa", null ],
    [ "OnDrag", "class_swipe_controller.html#a5d6462d855ab4cd7496dde16c7eba5f3", null ],
    [ "OnEndDrag", "class_swipe_controller.html#a59530aa6a8d5a2de12d7f39851ce3d2b", null ],
    [ "baseUnit", "class_swipe_controller.html#a422f7e579179be4a1e6e198d97068cc2", null ]
];