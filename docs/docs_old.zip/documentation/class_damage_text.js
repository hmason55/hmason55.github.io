var class_damage_text =
[
    [ "Init", "class_damage_text.html#ab66ed998f41cdeb84c22449950170f67", null ],
    [ "rectTransform", "class_damage_text.html#ae6860819b6715004f9f05314039aa978", null ]
];