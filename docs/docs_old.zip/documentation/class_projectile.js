var class_projectile =
[
    [ "end", "class_projectile.html#a488a27f52325780f1315b5c64949d9ca", null ],
    [ "spell", "class_projectile.html#adf481201408f58e0fe934bfe0e47229f", null ],
    [ "velocity", "class_projectile.html#a2d9755facfa238e047de85c626587cd2", null ]
];