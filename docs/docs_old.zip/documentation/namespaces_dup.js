var namespaces_dup =
[
    [ "SpriteParticleEmitter", "namespace_sprite_particle_emitter.html", null ]
];