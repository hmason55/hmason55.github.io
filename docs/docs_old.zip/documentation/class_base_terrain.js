var class_base_terrain =
[
    [ "TerrainType", "class_base_terrain.html#a5b782f4de5e1a2ca1343b4aa89a7dc9a", [
      [ "wall_top", "class_base_terrain.html#a5b782f4de5e1a2ca1343b4aa89a7dc9aaffe15f42468128e48325cf9206ab42e8", null ],
      [ "wall_side", "class_base_terrain.html#a5b782f4de5e1a2ca1343b4aa89a7dc9aa3efe6e3a4e45b10c24fca4149a87a786", null ],
      [ "ground", "class_base_terrain.html#a5b782f4de5e1a2ca1343b4aa89a7dc9aa578552719239a72a2d45ad422f67d24d", null ],
      [ "wall_hidden", "class_base_terrain.html#a5b782f4de5e1a2ca1343b4aa89a7dc9aafc32e3a8457bbaec473b09d4462c1ecd", null ],
      [ "ground_hidden", "class_base_terrain.html#a5b782f4de5e1a2ca1343b4aa89a7dc9aa8630ecda1c772caaa8625ab886c66db8", null ]
    ] ],
    [ "BaseTerrain", "class_base_terrain.html#a148b6e7aa268ebec1ab02c5e9f01f92d", null ],
    [ "Initialize", "class_base_terrain.html#aff9e343986e2b76d0fc22be3a5e246dc", null ],
    [ "LoadTexture", "class_base_terrain.html#ada3cddbd511be2890cbb9635d997441b", null ],
    [ "Optimize", "class_base_terrain.html#abda1c3ac02dc72095eb8c50ef68f8a2e", null ],
    [ "Shade", "class_base_terrain.html#ac52fb05dde7ffc3a3d88af0122516052", null ],
    [ "biome", "class_base_terrain.html#a89f7a3d77182f51a257cf1f503bb6fe9", null ],
    [ "render", "class_base_terrain.html#a845e9830b7282650856b64db83d7633b", null ],
    [ "shaded", "class_base_terrain.html#a5c1d125049a42d2b25ef2e09166bbd91", null ],
    [ "shadedSprite", "class_base_terrain.html#a6e60ba346bed94af204ded4f7fcf16ab", null ],
    [ "sprite", "class_base_terrain.html#a0af7f55356e035cde6cedadae6fbb34d", null ],
    [ "terrainType", "class_base_terrain.html#a381e5f59e57a301a70f79c32cf3ea300", null ],
    [ "walkable", "class_base_terrain.html#a403d7a199581bc910ecbf15009b532a6", null ]
];