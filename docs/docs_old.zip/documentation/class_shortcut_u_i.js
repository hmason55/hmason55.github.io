var class_shortcut_u_i =
[
    [ "BeginTurn", "class_shortcut_u_i.html#af20cdb51997f4ae7219a36a7bca851a3", null ],
    [ "Disable", "class_shortcut_u_i.html#a00f6fd2d64d2e5e978b749eafbe8f949", null ],
    [ "Enable", "class_shortcut_u_i.html#ae39ab7b830aff78693a4ddbaa3c59c3e", null ],
    [ "EndTurn", "class_shortcut_u_i.html#ab2181e3a43736c065ce2ff0d8066903e", null ],
    [ "OnBagShortcut", "class_shortcut_u_i.html#a2434bf0b041a115161fda12022d69f0b", null ],
    [ "OnCharacterShortcut", "class_shortcut_u_i.html#aa9dca9d0598a36d8df6555d26e75f176", null ],
    [ "OnEndTurnShortcut", "class_shortcut_u_i.html#ac6c1705acfb6d8393f36a73810d94958", null ],
    [ "OnMenuShortcut", "class_shortcut_u_i.html#a71824a1037ebef08af0938c0d731a498", null ],
    [ "SuggestEndTurn", "class_shortcut_u_i.html#a501d7c10166dca42125d04c805c617d1", null ]
];