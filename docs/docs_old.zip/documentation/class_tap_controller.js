var class_tap_controller =
[
    [ "OnPointerClick", "class_tap_controller.html#ac66ecd378ed27b1ded7402b758204bec", null ],
    [ "baseUnit", "class_tap_controller.html#ade0ce865eb39ef6a86a8015e5bb90a55", null ],
    [ "image", "class_tap_controller.html#a0da9433117902759e995719f5ef952aa", null ]
];