var class_hotbar =
[
    [ "CancelPreview", "class_hotbar.html#a0c213365074f45fd1b1010eabe3f3d4d", null ],
    [ "ClearCharges", "class_hotbar.html#ab54a6d27db19b4ed21014a782d74b3d1", null ],
    [ "ConfirmCast", "class_hotbar.html#a535ef71789d10c417b86bdd194e3e5b7", null ],
    [ "DisableHotkeys", "class_hotbar.html#a914ca0c61c4d64b0bde6e829064f71a9", null ],
    [ "EnableHotkeys", "class_hotbar.html#a37bca03a1dfd144a30bae3774eaab667", null ],
    [ "HideHotkeys", "class_hotbar.html#a2f8af9863292223ae00d361121164160", null ],
    [ "ReadyCast", "class_hotbar.html#a5ac379c585126b8e0e35c061b3388ecf", null ],
    [ "Recast", "class_hotbar.html#acda305961d329d3b329dbe4247539ef5", null ],
    [ "ShowHotkeys", "class_hotbar.html#a989b6728a8d86d60a851f68954edab90", null ],
    [ "SyncUnit", "class_hotbar.html#a1e796a0a133ee0743aa8585c05980f9b", null ],
    [ "UpdateHotkeys", "class_hotbar.html#a1b1cab633f4bf2347af2c0f04fa4b856", null ],
    [ "activeSpell", "class_hotbar.html#ab8c1abafc83f793590f0bf08981d50ef", null ],
    [ "baseUnit", "class_hotbar.html#a4a0bb9b20e1c7c8df122470fd540768b", null ],
    [ "castOptionsUI", "class_hotbar.html#a5712a8564c6cdbae01f3900648ce9fae", null ],
    [ "essenceUI", "class_hotbar.html#a02baa28776d8464929571a32904d78a5", null ],
    [ "tapController", "class_hotbar.html#a0281562a5bf5e3224f4d88f090bf3a84", null ]
];