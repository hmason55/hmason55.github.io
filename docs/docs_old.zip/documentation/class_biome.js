var class_biome =
[
    [ "BiomeType", "class_biome.html#a7ddcfcc6d4e88c5eb73df6827df862da", [
      [ "cavern", "class_biome.html#a7ddcfcc6d4e88c5eb73df6827df862daa420041ed55a01779d7c409d007070961", null ],
      [ "crypt", "class_biome.html#a7ddcfcc6d4e88c5eb73df6827df862daaf7bd616b6c841d2538735f76d1e02b57", null ],
      [ "dungeon", "class_biome.html#a7ddcfcc6d4e88c5eb73df6827df862daae0dc3209a149c3ae58feb149aef7cf3d", null ],
      [ "forsaken", "class_biome.html#a7ddcfcc6d4e88c5eb73df6827df862daa035c88a67814485689ec861c3685c316", null ],
      [ "ruins", "class_biome.html#a7ddcfcc6d4e88c5eb73df6827df862daad5472cde0923fa02dce57c6a1bc9985c", null ]
    ] ],
    [ "Biome", "class_biome.html#a0c6561c6514566b5170802d7699e761a", null ],
    [ "GetEnemySpawn", "class_biome.html#abfb2b6d9c6ae23d0d7f247e10b568a9e", null ],
    [ "biomeType", "class_biome.html#a0b8fc33054a627c978fa9d81573a9e1d", null ],
    [ "radius", "class_biome.html#a71b951bc82d85f930f9c6135a79a2bbc", null ],
    [ "x", "class_biome.html#ae63d1400ef2eaa0c520bec593aa2e90d", null ],
    [ "y", "class_biome.html#a3793ddae113d9c2b545a2dc7c6b96f3a", null ]
];