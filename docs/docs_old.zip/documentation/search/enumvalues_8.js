var searchData=
[
  ['ice',['Ice',['../class_spell.html#a3e228beaf92e2c035e6599aaf0ac2d2aa583d6a9fe10d672474e2cdca476113b7',1,'Spell']]],
  ['inescapabledamage',['InescapableDamage',['../class_effect.html#a28d85888db94ec53ee9cb75e9706f6e4a0a5f502a363a86eee6d11b9af7f0b020',1,'Effect']]],
  ['intelligence',['Intelligence',['../class_effect.html#af0ada789de40f58c24c46bf8ed2f300ca8f7ba58961e0fe40cfda61b412537fba',1,'Effect.Intelligence()'],['../class_spell.html#ae1316e04f731859b193c8b5c77ca3c70a8f7ba58961e0fe40cfda61b412537fba',1,'Spell.Intelligence()']]],
  ['iron_5fchain',['Iron_Chain',['../class_base_item.html#a3d8a039ad76206fc6622908254923b42ae68b72466d3a9a25070f08e85b67e59d',1,'BaseItem']]],
  ['iron_5fchain_5fcoif',['Iron_Chain_Coif',['../class_base_item.html#add9920d2f5a4fa91752714a8f3ab424ba3e6eb662206b30cc8c3741411b0f8300',1,'BaseItem']]],
  ['iron_5fchain_5fgloves',['Iron_Chain_Gloves',['../class_base_item.html#add9920d2f5a4fa91752714a8f3ab424bac1d082f5f0de88cfc2996a1c1fa5d534',1,'BaseItem']]],
  ['iron_5fchain_5fleggings',['Iron_Chain_Leggings',['../class_base_item.html#add9920d2f5a4fa91752714a8f3ab424bafbbd58845d24a6356dfc39b18c6f4071',1,'BaseItem']]],
  ['iron_5fchain_5fshoes',['Iron_Chain_Shoes',['../class_base_item.html#add9920d2f5a4fa91752714a8f3ab424ba24ef2c297cf24782f206d88992e91d0d',1,'BaseItem']]],
  ['iron_5fchain_5ftunic',['Iron_Chain_Tunic',['../class_base_item.html#add9920d2f5a4fa91752714a8f3ab424ba67c63a0f5de52c99454d1f347f026819',1,'BaseItem']]],
  ['iron_5fplate',['Iron_Plate',['../class_base_item.html#a3d8a039ad76206fc6622908254923b42abc164f0b4e865398d61a9bed45eada53',1,'BaseItem']]]
];
