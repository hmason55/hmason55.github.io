var searchData=
[
  ['nosetype',['NoseType',['../class_character.html#a638a71f8525dc3a59596f7f4a7836036',1,'Character']]]
];
