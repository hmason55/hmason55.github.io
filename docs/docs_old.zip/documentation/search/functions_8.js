var searchData=
[
  ['incrementanimation',['IncrementAnimation',['../class_base_unit.html#a007c44552627a4ee773771383198077f',1,'BaseUnit']]],
  ['init',['Init',['../class_damage_text.html#ab66ed998f41cdeb84c22449950170f67',1,'DamageText']]],
  ['initialize',['Initialize',['../class_announcement_text.html#a73025e6ac4349a61de65728eb1c926f9',1,'AnnouncementText.Initialize()'],['../class_base_terrain.html#aff9e343986e2b76d0fc22be3a5e246dc',1,'BaseTerrain.Initialize()']]],
  ['initzone',['InitZone',['../class_dungeon_manager.html#afc7ff9dc122b876f72a4f238496f3a26',1,'DungeonManager']]],
  ['isconsumable',['IsConsumable',['../class_base_item.html#a3888fc05b9a0589c098ed9a8c2f978f2',1,'BaseItem']]],
  ['isequipment',['IsEquipment',['../class_base_item.html#a251c4cb0509ed9191a07057f8ea388c6',1,'BaseItem']]],
  ['isstackable',['IsStackable',['../class_base_item.html#ad59a505bcfb8a026519ca912d0c1d8d3',1,'BaseItem']]]
];
