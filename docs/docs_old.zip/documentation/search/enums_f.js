var searchData=
[
  ['usage',['Usage',['../class_base_decoration.html#ad8b9ff9e5d7dc488ca94fed2efa45a6e',1,'BaseDecoration']]]
];
