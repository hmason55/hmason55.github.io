var searchData=
[
  ['damagetype',['DamageType',['../class_spell.html#a3e228beaf92e2c035e6599aaf0ac2d2a',1,'Spell']]],
  ['decorationtype',['DecorationType',['../class_base_decoration.html#a8adb8095439bd24fd3c2058b2ecbbf11',1,'BaseDecoration']]]
];
