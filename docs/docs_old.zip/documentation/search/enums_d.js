var searchData=
[
  ['scaling',['Scaling',['../class_spell.html#ae1316e04f731859b193c8b5c77ca3c70',1,'Spell']]],
  ['scalingtype',['ScalingType',['../class_effect.html#af0ada789de40f58c24c46bf8ed2f300c',1,'Effect']]],
  ['size',['Size',['../class_attributes.html#a40f1a5d5f1bcae42392039d603438a2a',1,'Attributes.Size()'],['../class_base_unit.html#a4c855b587a2eecd744c4c511aeda7da1',1,'BaseUnit.Size()']]],
  ['skincolor',['SkinColor',['../class_character.html#a726214a0fe480fffada7772697764824',1,'Character']]],
  ['spritepreset',['SpritePreset',['../class_base_unit.html#a086712791ce1a3cb5dc6448d8bbc1f62',1,'BaseUnit']]]
];
