var searchData=
[
  ['kill',['Kill',['../class_base_unit.html#ae32912e26fcd7ea4b251045742064af4',1,'BaseUnit.Kill()'],['../class_unit_behaviour.html#a9a32f3234ea6b89f686c6cd55d924348',1,'UnitBehaviour.Kill()']]]
];
