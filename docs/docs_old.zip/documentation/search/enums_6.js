var searchData=
[
  ['haircolor',['HairColor',['../class_character.html#a7940fffce9bfadb9e7abf15490cf8bb0',1,'Character']]],
  ['hairtype',['HairType',['../class_character.html#ada39ccb0e0be37a8f8f0e9a864eb5733',1,'Character']]],
  ['heavyarmortier',['HeavyArmorTier',['../class_base_item.html#a3d8a039ad76206fc6622908254923b42',1,'BaseItem']]]
];
