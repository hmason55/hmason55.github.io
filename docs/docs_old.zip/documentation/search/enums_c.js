var searchData=
[
  ['preset',['Preset',['../class_attributes.html#a2dcc4757e5dd7b7d518f43f4f194d175',1,'Attributes.Preset()'],['../class_effect.html#a84f32661374cee093139535ae75c58ad',1,'Effect.Preset()'],['../class_spell.html#a5520e850e7000a6156b3456672b72ed1',1,'Spell.Preset()']]]
];
