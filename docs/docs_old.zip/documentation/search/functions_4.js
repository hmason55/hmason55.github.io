var searchData=
[
  ['effect',['Effect',['../class_effect.html#a426033488b51897723a6aa15d1e66415',1,'Effect.Effect()'],['../class_effect.html#af2775716fce582c0a621f6c68ddb8574',1,'Effect.Effect(EffectType e, int d=0)'],['../class_effect.html#afc3ee0f70107f501148217c076092f40',1,'Effect.Effect(Preset p)']]],
  ['enable',['Enable',['../class_hotkey.html#ae078d4716dbd3a3c703a3ef341e56562',1,'Hotkey.Enable()'],['../class_shortcut_u_i.html#ae39ab7b830aff78693a4ddbaa3c59c3e',1,'ShortcutUI.Enable()']]],
  ['enablehotkeys',['EnableHotkeys',['../class_hotbar.html#a37bca03a1dfd144a30bae3774eaab667',1,'Hotbar']]],
  ['enablerendering',['EnableRendering',['../class_tile.html#a1baa5fe3ab8f887e8985a85fba21210a',1,'Tile']]],
  ['endcombat',['EndCombat',['../class_combat_manager.html#a8d14cf9a8265e20264151a615e309f12',1,'CombatManager.EndCombat()'],['../class_turn_queue.html#a9b3696b9a7672bbb8a79e3f0dc3ef393',1,'TurnQueue.EndCombat()']]],
  ['endhitanimation',['EndHitAnimation',['../class_base_unit.html#ac451e0e35631687d8a40a20ce68e0e51',1,'BaseUnit']]],
  ['endturn',['EndTurn',['../class_combat_manager.html#ae306deb3898e096bf5ad6cdd705b82fa',1,'CombatManager.EndTurn()'],['../class_shortcut_u_i.html#ab2181e3a43736c065ce2ff0d8066903e',1,'ShortcutUI.EndTurn()'],['../class_turn_queue.html#aadfdf0f72201cdc985ad2dbb9520eaee',1,'TurnQueue.EndTurn()']]],
  ['equip',['Equip',['../class_bag.html#a975e4ef7a5647327225e5b587b32c066',1,'Bag']]],
  ['equipitem',['EquipItem',['../class_bag_behaviour.html#a472cbdd4764a3f7980c19d83b3789651',1,'BagBehaviour']]],
  ['estimatedamage',['EstimateDamage',['../class_spell.html#aa5a9b6a6b13fcd1cfed9eb43e123ca23',1,'Spell']]]
];
