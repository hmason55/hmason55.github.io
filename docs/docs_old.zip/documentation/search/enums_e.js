var searchData=
[
  ['targetunittype',['TargetUnitType',['../class_spell.html#ad6592ed902a6627b69d56b0c78ca1b8b',1,'Spell']]],
  ['terraintype',['TerrainType',['../class_base_terrain.html#a5b782f4de5e1a2ca1343b4aa89a7dc9a',1,'BaseTerrain']]],
  ['transactiontype',['TransactionType',['../class_transfer_u_i.html#acb894008318cb07b7144beb2d6d81606',1,'TransferUI']]]
];
