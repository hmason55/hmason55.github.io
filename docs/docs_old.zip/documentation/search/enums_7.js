var searchData=
[
  ['id',['ID',['../class_base_item.html#add9920d2f5a4fa91752714a8f3ab424b',1,'BaseItem']]],
  ['intenttype',['IntentType',['../class_spell.html#a602b82de554076b542544262e7a95f19',1,'Spell']]]
];
