var searchData=
[
  ['feintswipe',['FeintSwipe',['../class_spell.html#a5520e850e7000a6156b3456672b72ed1a2ba21df265456583717bc5b35077e97a',1,'Spell']]],
  ['finger_5fjewelry',['Finger_Jewelry',['../class_base_item.html#a882a2962396f880c2e23755437245d37af6651a3c628a675a97c42da371a1e6a4',1,'BaseItem']]],
  ['fire',['Fire',['../class_spell.html#a3e228beaf92e2c035e6599aaf0ac2d2aabd2b7e5f85a6ea65065c4ebc6d7c95bb',1,'Spell']]],
  ['fireball',['Fireball',['../class_spell.html#a5520e850e7000a6156b3456672b72ed1aa8155b0ea02bae01cd41369018837d6b',1,'Spell']]],
  ['focus',['Focus',['../class_effect.html#a28d85888db94ec53ee9cb75e9706f6e4ae24ee2487879116dcab772c0ac4fe341',1,'Effect']]],
  ['foot_5farmor',['Foot_Armor',['../class_base_item.html#a882a2962396f880c2e23755437245d37ac319d71f7397840904d20b8c9e09ed45',1,'BaseItem']]],
  ['forsaken',['forsaken',['../class_biome.html#a7ddcfcc6d4e88c5eb73df6827df862daa035c88a67814485689ec861c3685c316',1,'Biome']]]
];
