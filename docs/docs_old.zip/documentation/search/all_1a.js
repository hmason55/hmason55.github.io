var searchData=
[
  ['zone',['Zone',['../class_dungeon_manager.html#a6558d4a01889674bf25c798f1b90a431',1,'DungeonManager.Zone()'],['../class_dungeon_manager.html#a4a1b9933b14faea37aeb07bd6f290774',1,'DungeonManager.zone()']]]
];
