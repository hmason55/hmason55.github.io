var searchData=
[
  ['category',['Category',['../class_base_item.html#a882a2962396f880c2e23755437245d37',1,'BaseItem']]],
  ['chunktype',['ChunkType',['../class_chunk.html#ab2e9c44541a726c19e8f0afbcf82894c',1,'Chunk']]],
  ['conditions',['Conditions',['../class_effect.html#ab13a718053e330a11f9f66a9b16f4686',1,'Effect']]]
];
