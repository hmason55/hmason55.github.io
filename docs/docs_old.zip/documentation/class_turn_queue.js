var class_turn_queue =
[
    [ "TurnQueue", "class_turn_queue.html#a15bbf8315c0dc5ad3d211872f3de296b", null ],
    [ "Add", "class_turn_queue.html#aa677cc3ae9812e45a5b7e8932c199e27", null ],
    [ "BeginCombat", "class_turn_queue.html#a7de50ac6b689f76c71d808962b6d1b86", null ],
    [ "EndCombat", "class_turn_queue.html#a9b3696b9a7672bbb8a79e3f0dc3ef393", null ],
    [ "EndTurn", "class_turn_queue.html#aadfdf0f72201cdc985ad2dbb9520eaee", null ],
    [ "NextTurn", "class_turn_queue.html#acae6f91ff8006307a04d4ee9362c1b7e", null ],
    [ "PrintTurns", "class_turn_queue.html#ae1c735b715ec963c76f0291cb9629338", null ],
    [ "RemoveTurns", "class_turn_queue.html#af6ee9af337f42a417812f4bc96f8d600", null ],
    [ "SortTurns", "class_turn_queue.html#afadc89a92617f7b2ee4e93025d2f2217", null ],
    [ "UnitInQueue", "class_turn_queue.html#a7f1a7e7055e613cbd17f1d76d9bfd261", null ],
    [ "Length", "class_turn_queue.html#ac5d7ed68bb4f7c1b6e93f55da966a7b3", null ],
    [ "queue", "class_turn_queue.html#a55c5122a7e3ce31ec8b79e9feb14bd27", null ]
];