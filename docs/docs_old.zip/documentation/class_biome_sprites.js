var class_biome_sprites =
[
    [ "container", "class_biome_sprites.html#a8fb08a6b474e7f7e8a40daf20a463de4", null ],
    [ "containerHighlights", "class_biome_sprites.html#a33ba33f3c0d2dac517d0e883d4763e13", null ],
    [ "decorationSmall", "class_biome_sprites.html#af23ad2a951ba13ed24370a3fe003bfa0", null ],
    [ "entrance", "class_biome_sprites.html#a28d07a7a7f5e0d8218f82adec2420b94", null ],
    [ "exit", "class_biome_sprites.html#ae504f59a35b8bb0f6147a2ca926f1c25", null ],
    [ "exitHighlights", "class_biome_sprites.html#a6bd7dcfd227829a0d67359dd4e67d666", null ],
    [ "ground", "class_biome_sprites.html#ad2325cb250ec73430e73738fb4da15f9", null ],
    [ "lockHighlights", "class_biome_sprites.html#a9afc6cf26fcf8ef18ee0ad3bfa95c000", null ],
    [ "locks", "class_biome_sprites.html#a9965a03afe286f1989281b3ccc3c6d51", null ],
    [ "wallSide", "class_biome_sprites.html#ae50f2ead3749017429753f14a0acf8ff", null ],
    [ "wallTop", "class_biome_sprites.html#a4653b5307c630bec66c3b4c14f8d54f0", null ]
];