var class_camera_controller =
[
    [ "MoveToTarget", "class_camera_controller.html#a79831008bb764801df46a3c91343a524", null ],
    [ "SnapToTarget", "class_camera_controller.html#a9e2d7df7c696c1c2ce48384933c5d1ab", null ],
    [ "UpdateResolution", "class_camera_controller.html#a4894dc3111b871a8bf5ff422d30c1689", null ],
    [ "_target", "class_camera_controller.html#ac211a3ef97d78311cab3215e02dcaa8e", null ],
    [ "target", "class_camera_controller.html#a1557d6d0a4b70b6bb53f5a913329d0d0", null ]
];