var class_unit_sprites =
[
    [ "armorT1", "class_unit_sprites.html#a240fd076990a1d5415b0bf646811def5", null ],
    [ "armorT2", "class_unit_sprites.html#a067a815643b14259b578d068a89fe847", null ],
    [ "hit", "class_unit_sprites.html#a04dea1b07a4c9d2268e710338281d8f6", null ],
    [ "idle", "class_unit_sprites.html#a7dab10edddb2f02aac97a699ad4bd877", null ],
    [ "primaryT1", "class_unit_sprites.html#a628613428a3a72eacba6610e0b332a51", null ],
    [ "primaryT2", "class_unit_sprites.html#a2991644582def68ae1ab58e7f887acb8", null ],
    [ "secondaryT1", "class_unit_sprites.html#ad5ba8963e97a5efd3bb56be95e573b1e", null ],
    [ "secondaryT2", "class_unit_sprites.html#afce363dd582be88b65df9b081a932400", null ],
    [ "skin", "class_unit_sprites.html#a0fb8aecfe21f48454c0ff88e3e62b46b", null ]
];