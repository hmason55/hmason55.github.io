var class_attributes_u_i =
[
    [ "ToggleUI", "class_attributes_u_i.html#a7cb7b0cebe1130576d6bbd279cb62ac1", null ],
    [ "baseUnit", "class_attributes_u_i.html#a346e8b850f9b6c18b78fc7175d89bea7", null ]
];