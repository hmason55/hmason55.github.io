var class_player_data =
[
    [ "PlayerData", "class_player_data.html#a7dc81cafeb02f4843f6c6ec738323ad9", null ],
    [ "slot", "class_player_data.html#ad3b89e484ba4ff9a3dcc3a477af1453a", null ],
    [ "attributes", "class_player_data.html#a0cb768b809c4518326a7f5092ef6fb76", null ],
    [ "bag", "class_player_data.html#a30f64ffcbf5541044cadb3e5b038acb7", null ],
    [ "character", "class_player_data.html#a15faab09286a8d43714c7659a9d1b6bd", null ],
    [ "currentZone", "class_player_data.html#a8e1bd4482b28bb85156d2aef7be04809", null ],
    [ "retrievalBag", "class_player_data.html#a7ce87c3307030f2a67f5628ca1c69c82", null ],
    [ "retrievalMode", "class_player_data.html#ae258f6bda605a5d3c9d4d701af4bf4d4", null ],
    [ "retrievalZone", "class_player_data.html#aed5e24eed1db76e3d8954ab05e8f342c", null ],
    [ "targetZone", "class_player_data.html#a5671b8f488e96c5263bb062200ae781a", null ]
];