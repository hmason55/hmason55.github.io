var class_announcement_text =
[
    [ "Initialize", "class_announcement_text.html#a73025e6ac4349a61de65728eb1c926f9", null ]
];