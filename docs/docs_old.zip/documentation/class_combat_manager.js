var class_combat_manager =
[
    [ "BeginCombat", "class_combat_manager.html#ab5d0c356fd55e86d62b03c015754abee", null ],
    [ "BeginTurnLoop", "class_combat_manager.html#aa31394843beacdbfd52d683a68a7f454", null ],
    [ "CheckCombatStatus", "class_combat_manager.html#aea6dfda807c4ec793ed26c5d220b84fb", null ],
    [ "EndCombat", "class_combat_manager.html#a8d14cf9a8265e20264151a615e309f12", null ],
    [ "EndTurn", "class_combat_manager.html#ae306deb3898e096bf5ad6cdd705b82fa", null ],
    [ "GetAllBaseUnits", "class_combat_manager.html#a02eb44e3f4fab4f210d4ecda54fa1272", null ],
    [ "ValidateMoveTile", "class_combat_manager.html#a6f648795292255b600e92eefcf960ded", null ],
    [ "turnQueue", "class_combat_manager.html#a6316ac49fbaf2e16426313d12749761d", null ]
];